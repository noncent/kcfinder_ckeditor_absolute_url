<?php require_once 'settings.php'; ?>
<head>
	<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	<script type="text/javascript">
		var _BASE_URL_ = "<?=APP_URL;?>";
	</script>
</head>
<body>
	<h1>CKEditor KcFinder Integration using PHP</h1>
	<p>
		<textarea id="ck_editor_demo" name="ck_editor_demo" rows="10" cols="80" class="ckeditor"></textarea>
	</p>
	<script type="text/javascript">
	/**
	 * Make text area as Rich Text Format
	 * Get element id and make RTF (Rich Text Formatter)
	 */
	 CKEDITOR.replace( 'ck_editor_demo' );  
	</script>
</body>
</html>